import javax.swing.JOptionPane;
import java.sql.*;

public class Menu 
{
	public static boolean op = true;
	public static DAO dao = new DAO();

	public static void main(String args[]) throws SQLException, Exception
	{
		while(op)
		{
			String opcao = JOptionPane.showInputDialog("[1] - Salvar\n[2] - Exibir\n[3] - Exibir Todos\n[4] - Remover\n[0] - Sair");

			switch(opcao)
			{
				case "1":
				{
					salvar();
					op = true;
				}
				break;
				case "2":
				{
					buscar();
					op = true;
				}
				break;
				case "3":
				{
					buscarTodos();
					op = true;
				}
				break;
				case "4":
				{
					remover();
					op = true;
				}
				break;
				case "0":
				{
					JOptionPane.showMessageDialog(null, "Saindo...");
					op = false;
				}
				break;
				default: JOptionPane.showMessageDialog(null, "Opção invalida!");
			}//switch
		}//while
	}//main

	public static void salvar()throws SQLException, Exception
	{
		while(op)
		{
			String opcao = JOptionPane.showInputDialog("[1] - Professor\n[2] - Aluno\n[0] - Sair");
			switch(Integer.parseInt(opcao))
			{
				case 1:
				{
					dao.salvarBd(Integer.parseInt(opcao));
				}
				break;
				case 2:
				{
					dao.salvarBd(Integer.parseInt(opcao));
				}
				break;
				case 0:
				{
					op = false;
				}
				break;
				default: JOptionPane.showMessageDialog(null, "Opção invalida!");
			}
		}
	}//salvar

	public static void buscar() throws SQLException, Exception
	{
		while(op)
		{
			String opcao = JOptionPane.showInputDialog("[1] - Professor\n[2] - Aluno\n[0] - Sair");
			switch(Integer.parseInt(opcao))
			{
				case 1:
				{
					dao.buscarBd(Integer.parseInt(opcao));
				}
				break;
				case 2:
				{
					dao.buscarBd(Integer.parseInt(opcao));
				}
				break;
				case 0:
				{
					op = false;
				}
				break;
				default: JOptionPane.showMessageDialog(null, "Opção invalida!");
			}
		}
	}//Buscar

	public static void remover() throws SQLException, Exception
	{
		while(op)
		{
			String opcao = JOptionPane.showInputDialog("[1] - Professor\n[2] - Aluno\n[0] - Sair");
			switch(Integer.parseInt(opcao))
			{
				case 1:
				{
					dao.remover(Integer.parseInt(opcao));
				}
				break;
				case 2:
				{
					dao.remover(Integer.parseInt(opcao));
				}
				break;
				case 0:
				{
					op = false;
				}
				break;
				default: JOptionPane.showMessageDialog(null, "Opção invalida!");
			}
		}
	}//remover

	public static void buscarTodos() throws SQLException, Exception
	{
		while(op)
		{
			String opcao = JOptionPane.showInputDialog("[1] - Professor\n[2] - Aluno\n[0] - Sair");
			switch(Integer.parseInt(opcao))
			{
				case 1:
				{
					dao.buscarTBd(Integer.parseInt(opcao));
				}
				break;
				case 2:
				{
					dao.buscarTBd(Integer.parseInt(opcao));
				}
				break;
				case 0:
				{
					op = false;
				}
				break;
				default: JOptionPane.showMessageDialog(null, "Opção invalida!");
			}
		}
	}//BuscarTodos
}//Menu
